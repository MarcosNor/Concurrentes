//package unam.fc.concurrent.practica2;

public class Nodo {
	public String item;
	public Nodo next;
	public Nodo(String item) {
		this.item = item;
	}
}